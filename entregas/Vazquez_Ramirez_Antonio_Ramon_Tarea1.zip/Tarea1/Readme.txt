Para ejecutar el código, simplemente poner tdos los archivos .py en la misma carpeta, abrir powershell, cmd o editor de python favorito. Mover a la localización de la carpeta, y ejecutar main.py

Ejemplo:
---------------

archivos en carpeta C:

powershell:

C: python main.py
-------------------